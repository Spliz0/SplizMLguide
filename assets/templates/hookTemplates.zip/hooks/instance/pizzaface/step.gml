//runs on every step inside of pizzaface (before the rest)
//return true/false to allow pizzaface step code
//return false and you can do your own code

if MODIFIERS.PPmode
{
    maxspeed += 0.1;
    return true;
}