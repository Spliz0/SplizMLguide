/*
runs during the draw function inside pizzaface
return true/false to allow the draw code to run
useful for straight up drawing something different
*/

if MODIFIERS.PPmode
{
    draw_sprite(sprite_index,image_index,x + choose(-100,100),y + choose(-100,100));
    return false;
}
