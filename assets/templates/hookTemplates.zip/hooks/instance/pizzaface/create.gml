//runs when pizzaface is created and vars are setup
//setup sprites as example
if obj_player1.character == "PP"
{
    movespr = MOD_GLOBAL.spr_PPfacemove;
    slowspr = MOD_GLOBAL.spr_PPfaceslow;
    stunspr = MOD_GLOBAL.spr_PPfacestun;
    spr_dead = MOD_GLOBAL.spr_PPfaceded;
}