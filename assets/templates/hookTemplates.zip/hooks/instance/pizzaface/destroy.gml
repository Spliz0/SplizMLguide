//runs when pizzaface is destroyed
//return true/false to allow the normal code to run
//useful to remove the normal one so only your new one shows

if MODIFIERS.PPmode
{
    with instance_create(x,y,obj_sausageman_dead)
    {
        sprite_index = other.sprite_index;
    }
    return false;
}