//runs during the alarm1 event inside pizzaface
// return true/false to allow it to run
//this is the afterimage creator, you can draw other color afterimages i guess.