//runs at the beginning of every room inside of pizzaface
//return true/false to allow the code to run (saved x is kept regardless)
//replace it with your own if you want
//also useful for setting room speeds with the "Slow pizzaface" CU lapping option


if MODIFIERS.PPmode
{
    if room == tower_1
    {
        pepspeed = 12;
    }
}