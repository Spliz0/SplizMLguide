/*
return true or false to allow pizzaface to do
the laugh intro animation added in REMIX
useful if you reskin pizzaface and don't make a laugh sprite
*/
if MODIFIERS.PPmode
{
    return false;
}