//Runs when ANY object is destroyed
//code runs inside of the object being destroyed
//determines if the object is destroyed

if object_index == obj_lapportal
{
    return false;
}