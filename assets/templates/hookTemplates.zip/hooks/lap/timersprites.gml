/*
runs to change sprites of the panic countdown timer
return a struct with ONLY
the sprites you want to change.
changeable sprites:
pizzaface1 - sleeping sprite
pizzaface2 - waking sprite 
pizzaface3 - SHOWTIME! sprite end
pizzafaceback - recover from parry sprite
pizzafaceparry - being parried sprite
pizzafacewait - recovering loop sprite
tower - crumbling tower sprite
johnface - john timer progress sprite
johnfacesleep - john timer sleeping from excess time sprite
johnfaceback - john returning when time is added sprite
bar - the actual timer bar outline sprite
barfill - the texture sprite for the bar filling
*/

if character == "PP"
{
    return {
        pizzaface1: MOD_GLOBAL.timerface1,
        pizzaface2: MOD_GLOBAL.timerface2,
        pizzaface3: MOD_GLOBAL.timerface3,
        tower: MOD_GLOBAL.timertower
    };
}