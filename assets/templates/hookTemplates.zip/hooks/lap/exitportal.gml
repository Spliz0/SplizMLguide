/*
runs when the player EXITS the lap portal,
so when the player goes to where john was.abs
You can use this to add time to some sort of timer mostly,
or running checkpoint-like code for lapping
*/

if MODIFIERS.PPmode
{
    with obj_mod_object
    {
        if __OBJECT.name == "obj_PPconst"
        {
            pptime += 100;
        }
    }
}
