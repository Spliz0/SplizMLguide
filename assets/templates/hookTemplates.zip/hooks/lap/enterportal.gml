/*
runs when the player ENTERS the lap portal,
so when you are almost back to the exit.
You can do things like saving info for a checkpoint

*/

if MODIFIERS.PPmode
{
    with obj_mod_object
    {
        if __OBJECT.name == "obj_PPconst"
        {
            curlapcollect = global.collect;
        }
    }
}