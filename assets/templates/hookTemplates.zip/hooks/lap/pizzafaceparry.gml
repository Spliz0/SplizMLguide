//return true/false to allow the player to parry pizzaface
//may be useful for making lapping mods harder
if MODIFIERS.PPmode && global.laps > 1
{
    return false;
}