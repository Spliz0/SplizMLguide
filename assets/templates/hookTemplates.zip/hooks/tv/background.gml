/*return true/false to show the TV background
you can use this to return your own background probably
 to match custom level escape BGS or if you have 
 a really weird tv or something
 */
if obj_player1.character == "PP" && global.leveltosave == "cyop_crunchyConstructionidfk"
{
    global.SSpanicdraw = true;
    //set like a variable or somethin so a controller object
    //draws that  neat background i mentioned
    return false;
}