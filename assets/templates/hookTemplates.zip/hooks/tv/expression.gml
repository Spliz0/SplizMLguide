//set things to happen when the TV expression check runs
//mostly used reactively after you set a sprite to reset it
switch expressionsprite
{
    case global.PPsprs.poundtv;:
        with obj_player1
        {
            if state != "superpound"
            {
                other.state = states.tv_whitenoise;
                other.expressionsprite = noone;
            }
        }
}