/*
runs code after the TV HUD itself is drawn,
so you could setup something for right after
*/
