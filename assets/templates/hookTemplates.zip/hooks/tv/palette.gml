//return a struct, 2 values for the image and palette part to set the HUD tv color
//can use the default CU colors, or your own palette sprite
//You can FORCE by always returning, or setting the default color with the tvcolor == 0 check
if (obj_player1.character == "PP"  && global.tvcolor == 0)
{
    return
    {
        spr_palette: spr_tv_palette, // pull from the default palette
		paletteselect: 5//index
    }
}
