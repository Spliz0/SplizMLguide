//return a sprite to be shown on the tv with transition
//and buffer like a transformation
if obj_player1.state == "PPsuperslide"
{
    return global.PPsprs.slidetv;
}