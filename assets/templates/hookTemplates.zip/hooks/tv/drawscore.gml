//return true/false to allow the HUD score to show

if character == "PP"
{
    return false;
    //bad example, just removes the score, why?
}