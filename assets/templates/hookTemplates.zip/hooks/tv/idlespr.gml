/*
return a sprite for the TV HUD to use as a default
useful for lapping tvs
*/

if character == "PP" && global.lapmode == 2 && global.laps > 1
{
    return MOD_GLOBAL.spr_PPlaptv;
}