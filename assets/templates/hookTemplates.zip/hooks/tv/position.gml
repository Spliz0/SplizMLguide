//return an array for an X and Y value to offset the TV HUD
if character == "PP"
{
    return [SCREEN_WIDTH * 0.8,SCREEN_HEIGHT * 0.2]
}