/*
can return true/false to determine if the HUD rank is shown
*/
if character == "PP"
{
    return false;
    //not a good example, just removes the rank
}