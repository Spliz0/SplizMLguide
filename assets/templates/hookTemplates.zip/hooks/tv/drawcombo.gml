/*
return true/false to let the combo bar be drawn
to the hud, or make your own.
*/

if character == "PP" && room == tower_1
{
    return false;
//not a good example, just makes the combo not show in the tower hub
}