//return true/false to let the BLUE player afterimages
//Blue like the uppercut in the old afterimage style
if obj_player1.character == "PP" && obj_player1.state == "superdash"
{
    return true;
}