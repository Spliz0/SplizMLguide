//determine if the player can stand/run/whatever on 
//water without switching to the scared jump state
if obj_player1.state == "PPsuperdash"
return false;