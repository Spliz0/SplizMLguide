/*
runs BEFORE the functions for the player state code runs
You can return true/false to allow the code for that state
also ofc run things before the state properly starts
example: make crouch state do nothing
*/

if state == 100
{
    sprite_index = spr_crouch;
    hsp = 0;
    movespeed = 0;
    if !key_down
    {
    state = 0;
    }
    return false;
}
