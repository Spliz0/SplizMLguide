//code that runs AFTER you start your walljump,
//you can add gravity for example

if MODIFIERS.WackGravity
{
vsp +=4;
}