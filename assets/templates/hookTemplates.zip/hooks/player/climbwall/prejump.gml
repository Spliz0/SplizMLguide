/*
runs right before you walljump, so you can return true/false
to let your character walljump
*/

if character == "PP"
{
    if sprite_index = spr_clownpp;
    {
        return false;
    }
}