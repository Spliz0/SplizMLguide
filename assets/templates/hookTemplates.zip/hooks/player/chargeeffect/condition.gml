/* Return true/false to keep chargeeffect
(yellow thing in front of mach) alive like in kill states
*/
if obj_player1.state == "superslide"
{
    return true;
}