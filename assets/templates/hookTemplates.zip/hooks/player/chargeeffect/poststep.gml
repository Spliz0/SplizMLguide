/*
used to affect the charge effect after the step code runs
could set the offsets after the player sprite is 
affected in normal step code (x,y,image_xscale,image_yscale)
*/
if playerid.character == "PP"
{
    if playerid.state == "superdash"
    {
        x += (10 * playerid.xscale);
        image_xscale *= 1.1;
    }
}
