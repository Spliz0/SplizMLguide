/*
runs right before the charge effect does its thing,
can affect thngs before the player does some things 
in step code probably
*/