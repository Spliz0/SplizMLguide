/*
used to make the player show a certain sprite without 
actually affecting the real sprites, and code related to it
can also be used to make peter-like palettes


use this first check to avoid a cosmic clone issue
*/
if object_index == obj_player1
{

    if paletteselect == 15 
    {
    return MOD_GLOBAL.PPbrian;
    }
}