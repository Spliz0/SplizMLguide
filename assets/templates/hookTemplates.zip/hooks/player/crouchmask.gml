//determines if the player uses the hitbox that is
//normally used when crouching, useful for new slide-type 
//states i guess, or if your character is small
if obj_player1.state == "PPsuperslide"
return false;