//return true/false to let the player afterimages blur
//and seem more transparentish, like noise drill afterimages
if obj_player1.character == "PP" && obj_player1.state == "superdash"
{
    return true;
}