//this code determines if the player can kill 
//enemies in this state automatically, can be used 
//for a ground-pound like move or something dangerous

if obj_player1.state == "PPsuperduperpound"
{return true;}