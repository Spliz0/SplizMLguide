//return true/false to allow the player to be hurt

if obj_player1.state == "SuperMode"
{
return false;
}