/*
during the step code, the player object 
runs the "state machine" which triggers a function based
on the player's state. The poststate hook allows you to run
code after that happens, while being updated on the player state.
This can be used to add extra code for the states, such
as making your groundpound faster like in this example.

*/
if state == states.groundpound
{
    vsp += 1;
}
/*
The code is run within the player object,
so you dont have to specify like in the example.
Check for your character I guess. 
Both state names and numbers work of course;

*/
