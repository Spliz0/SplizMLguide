//runs when the player is reset, so reset ur objects in it
//(DOESNT INCLUDE FIRST LEVEL START)

with obj_mod_object
{
    if __OBJECT.name == "obj_PPchaser"
    {
        mode = 1;
    }
}