//return how high your character jumps by default
//make a character like mario jump higher or somethin
if global.triplejumpprogress == 2 && obj_player1.character == "M"
{
    return 20;
}