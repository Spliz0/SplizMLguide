/*
code that runs AFTER your longjump starts, maybe
setup an interaction for a new state
*/

if character == "PP"
{
    if place_meeting(x + hsp,y + vsp,obj_solid)
    {
        state = "superdash";
        xscale *= -1;
    }
}