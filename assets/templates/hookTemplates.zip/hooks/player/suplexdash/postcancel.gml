//code that runs after your character cancels with a grab


if character == "PP"
{
    state = "canceldash";
    sprite_index = spr_canceldash;
    image_index = 0;
    movespeed = 10;
}