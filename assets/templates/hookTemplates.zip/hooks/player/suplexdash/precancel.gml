/*
return false to cancel your grab-related move ahead of time
*/

if character == "PP"
return false;