/*
runs right before the player does a grab dash,
return true/false on whether the nornal code should run
*/
if character == "PP"
{
    if place_meeting(x + hsp,y + vsp,obj_solid)
    {
        state = "superbounce";
        sprite_index = spr_superbounce;
        xscale *= -1;
    }
}