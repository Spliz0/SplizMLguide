//code that runs AFTER the grab code is performed
//WILL NOT WORK if preperform.gml cancels the code

if character == "PP" && !grounded
{
    state = "superdash";
    sprite_index = spr_superdash;
    image_index = 0;
}