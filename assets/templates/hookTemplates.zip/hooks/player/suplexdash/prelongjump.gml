/*
run code before your long jump starts, like adding speed
can return true/false to let the longjump happen
if returned false the code runs, if returned true
you dont longjump
*/
if character == "PP"
{
 movespeed +=2;
 hsp +=2*xscale;
}