/*
used to do things and change the grab dash sprite
you can return true as a way to exit
*/

if character != "PP"
return true;

if !grounded
{
    if key_up
    {
        sprite_index = spr_flail;
        image_index = 0;
    }
    return false;
}