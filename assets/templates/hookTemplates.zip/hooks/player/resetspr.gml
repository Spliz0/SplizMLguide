/*
this code runs right after the player sprites are set
you can use this to set any player sprite variables
manually here, like snick ones for a partial reskin
this also means it runs inside the player object
*/
spr_jump = spr_playerN_jump;
spr_fall = spr_playerN_fall;