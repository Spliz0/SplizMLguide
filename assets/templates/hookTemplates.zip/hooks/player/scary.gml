//runs when you are in enemy sights inside of the enemy objects
//so remember to use obj_player1.
//return true or false to determine if enemies should be scared

if obj_player1.character == "N" && obj_player.state == 121
{
return true;
}

