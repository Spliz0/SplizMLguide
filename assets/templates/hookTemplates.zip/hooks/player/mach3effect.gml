//returnn true/false to let the mach 3 colored trail show
//these are the dual color afterimages(red & green for pep)
if obj_player1.character == "PP" && obj_player1.state == "superdash"
{
    return true;
}