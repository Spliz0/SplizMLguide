//runs when the panic section starts, 
//whether by pillar john or something else weird
//useful to trigger something in a custom modifier
with obj_mod_object
{
    if __OBJECT.name == "obj_PPchaser"
    {
        mode = 2;
    }
}