//runs AFTER the draw code so if you draw something
//it will overlay on top of the draw stuff, it can
//be used to add extra pieces, think of the swap mode -
// "player X wins! pieces" for this

if obj_player1.character == "PP" && MODIFIERS.PPmode
{
    draw_sprite(MOD_GLOBAL.spr_PPcool,0,SCREEN_WIDTH*0.8,SCREEN_HEIGHT *0.2)
}