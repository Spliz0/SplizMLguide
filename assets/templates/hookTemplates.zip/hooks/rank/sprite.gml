//return a sprite for the rank animation
//useful for new ranks/modifiers/laps
if character == "PP" && MODIFIERS.PPmode
{
    return MOD_GLOBAL.PPmodewin;
}