//return a color for the rank to use at the ending of the animation/scoring
if obj_player1.character == "PP"
{
    return c_red;
}