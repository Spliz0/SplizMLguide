/*
runs BEFORE the rank draw code, so if you draw 
something it can be covered by the other stuff, but
you can also return false to not draw the default
and draw your stuff new
*/
if global.goodmode
{
    return false; //dont do this example
}