//runs every step during the rank animation
//can be used to set the sprite or add some object/HUD part

if obj_player1.character == "PP"
{
    if MODIFIERS.PPmode && global.collect > 1500
    {
        if !instance_exists(obj_transfotip)
        {
            with instance_create(1,1,obj_transfotip)
            {
                text = "Ya did it!"
            }
        }
    }
}