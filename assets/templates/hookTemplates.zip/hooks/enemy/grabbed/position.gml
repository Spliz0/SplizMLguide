/*
return false to cancel the code for setting the 
enemy offsets when being affected by grab moves, used 
to make it fit your character if it has a weird grab sprite
use the p variable to refer to the player
*/

if p.character == "PQ"
{
    if p.state == 79 && p.sprite_index == p.spr_swingding
    {
        return true;
    }
    if p.state == 76 || p.state == 61 && sprite_index == p.spr_piledriver
    {
        //add offset code here based on your sprite
        //just set x and y, trial and error
        return false;
    }
}