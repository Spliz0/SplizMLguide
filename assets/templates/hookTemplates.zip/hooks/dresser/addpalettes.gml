//runs while the palettes are being added to the dresser
//add palettes to the normal list here, you can also add 
//pattern+palette combos or specific characters properly here
switch (characters[sel.char].char)
{
    case "PP"://in the example we add 1 pattern only for PPguy, mixed with the 8th one by default and not mixable with others
        add_pattern(global.PPguypattern, "ppguy").set_entry("ppguy").set_palette(8).mixable = false;
    break;
}