//AFTER palettes and patterns are added to the dresser lists
//useful for unlockables and pattern mods

with (obj_skinchoice)
{
//example adds a new sprited pattern for all characters, using their default mix palette
    add_pattern(MOD_GLOBAL.spr_pattern1, "patternMY1").set_entry("MY1").set_palette(12);
}