//runs after the pause menu draw code (consistently), to modify or overlay something


if character == "PP"
{
    draw_sprite(MOD_GLOBAL.spr_pausepose,0,SCREEN_WIDTH * 0.2,SCREEN_HEIGHT * 0.8)
}