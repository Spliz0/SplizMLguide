/*
run code AFTER every step event WHILE THE GAME'S PAUSED
basically a step code for the pause event if you dont 
want a controller object
*/
