//runs ONCE after the game is paused and the initial code runs
//setup variables for the other stuff or a controller object