//return an FMOD event to set the sound that plays
//when the player inputs in the pause menu

return "event:/PPmod/sfx/pausemove";