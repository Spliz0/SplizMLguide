/*
runs BEFORE the main draw code, and return true/false
to allow it to happen/replace it with your own
*/

if character == "PP"
{
    return true;
    //I am NOT making a pause menu for this example sorry
}