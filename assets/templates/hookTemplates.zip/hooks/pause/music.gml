//set the pause menu music with an FMOD event

return "event:/PPmod/music/pausemuse"