//used to check if you can save your level score
//useful if your modifier messes too much with score or overhauls too much
//return true or false

if MODIFIERS.PPmode = true
{
    return false;
}