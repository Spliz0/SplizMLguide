//DOESNT WORK CURRENTLY, but you would've 
//able to return an FMOD event to, 
//well, force a certain song to play instead