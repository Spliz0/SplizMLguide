//return true to have your music lose focus when collecting a treasure
return true;