//return a single FMOD event, or an array with 2 parts
//in order, the actual entrance song, and the secret theme
//MAY RARELY NOT WORK,ITS A HOOK ISSUE NOT YOU
if !instance_exists(obj_player1) exit;
if obj_player1.character == "PP"
{
    return ["event:/PPmod/music/entryway","event:/PPmod/music/entrysecret"]
}