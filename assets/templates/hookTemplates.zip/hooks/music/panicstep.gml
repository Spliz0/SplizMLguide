//like the name, runs every step during panic
//can be used to check and set FMOD states of your music