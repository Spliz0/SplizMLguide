/*
return an FMOD event path to set the music for the escape
argument0 is the default event, so account for Noise,
Cosmic Clones,laps, etc.

*/
if obj_player1.character == "PP"
{
    if argument0 = "event:/modded/cosmicclone" return "event:/PPmod/music/cosmicclone";
    if argument0 == "event:/music/pizzatime"
    {
        return "event/PPmod/music/escape";
    }
    if argument0 == "event:/modded/lap3"
    {
        return "event/PPmod/music/lapperdelight";
    }
}