/* 
Return true/false to keep your state instead of bumping
(for destroyable blocks only)
think of something like vigilante dive/slide
*/

if obj_player1.state == "superslide"
{
    return false;
}