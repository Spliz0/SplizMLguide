/*
return true/false, makes your character break destroyable
blocks when touching them if true (NOT METAL BLOCKS)
*/
if obj_player1.character == "PP"
{
    if obj_player1.state == "superdash"
    {
       return true;
    }
}
