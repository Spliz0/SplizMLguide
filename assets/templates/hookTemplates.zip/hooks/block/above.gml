/*
return true/false to make your character break destroyable
blocks ABOVE your character (not metal blocks)
*/
if obj_player1.state == "superfly"
{
    return true;
}