/*
return true/false to make characters break METAL blocks BELOW them
*/
if obj_player1.state == "superpound"
{
    return true;
}