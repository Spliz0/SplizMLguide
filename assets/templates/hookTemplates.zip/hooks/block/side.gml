/*
return true or false to break destroyable blocks (not metal)
on the SIDE of your character
*/
if obj_player1.state == "superslide"
{
    return true;
}