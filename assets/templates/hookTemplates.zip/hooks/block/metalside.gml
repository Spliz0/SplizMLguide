/*
return true/false to let your character break METAL blocks
on your SIDE
*/
if obj_player1.state == "superdash"
{
    return true;
}