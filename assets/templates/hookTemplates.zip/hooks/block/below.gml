/* 
return true/false make characters break destroyables
BELOW your player (not metal blocks) 
*/
if obj_player1.state == "superpound"
{
    return true;
}