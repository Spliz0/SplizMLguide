//constantly to check if your S rank can get upgraded to P
//return true or false

if global.collect == global.srank *1.2
{
    return true;
}
else
{
    return false
}