//runs when the MODIFIERS reset, like exiting a level,
//so account for things here

if (global.leveltosave == -4)
{
MODIFIERS.PPmode = 0;
with obj_mod_object
{
    if __OBJECT.name == "PPchaser"
    {
        instance_destroy();
    }
}
}