//runs when the modifiers menu is opened and prepared
//add your modifiers here and check the level for compatibility

if level == "tutorial" exit;
/*
3 values in order, modifier name(code name), 6 DIGIT hex code for color,
and a function on how to draw a preview for your modifier
use the 3 constant values in your function, val, width, height

*/
add_modifier("PPmode", #0e02f7, function(val)
{
    
    draw_set_font(global.font_small)
    draw_set_align(fa_center)
    if (val)
    {
        draw_text(width/2,height/2,"Get Ready")
    }
    else
    {
        draw_text(width/2,height/2,"Try me")
    }
}); 