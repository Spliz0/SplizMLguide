//when the game needs to draw the icon to represent your
//custom modifiers, 1 image
if argument0 == "PPmode" 
{
    return {
        sprite: MOD_GLOBAL.spr_modifierIcons,
        image: 1 //EX: I want the second image from the sprite
    }
}