//AFTER the player spawns and is ready.(level start)
//probably useful for spawning a chase near the player's spawn
with obj_mod_object
{
    if __OBJECT.name == "obj_PPchaser"
    {
        x = obj_player1.x;
        y = obj_player1.y;
    }
}