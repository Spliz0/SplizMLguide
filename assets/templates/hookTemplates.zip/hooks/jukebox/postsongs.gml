//AFTER the songs are placed into the jukebox, you can use
//functions to add new sections and songs

with new JukeboxSection("Juke Test", 4)
{
	
	add_song("event:/Mymod/jukebox/thingy", "Thingy - Pingass");
	
add_separator();
add_multisong("event:/Mymod/jukebox/song", "song (OLD)- The",
	"event:/Mymod/jukebox/songNEW", "Song (NEW) - The");
}