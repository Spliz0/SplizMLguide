/*
set some sprites for the POINTS HUD (pizza with numbers)
all settable sprites in example
*/
if obj_player1.character = "PP"
{
    heatfillR = spr_heatmeter_fill;
	 heatmeterR = spr_heatmeter;
	 heatpalR = spr_heatmeter_palette;
		
	 pizzascoresprR = MOD_GLOBAL.weirdpizza;
	 pepperspriteR = MOD_GLOBAL.weirdpizzapepper;
	 pepperonispriteR = MOD_GLOBAL.weirdpizzapepperoni;
	 olivespriteR = MOD_GLOBAL.weirdpizzaolives;
	 shroomspriteR = MOD_GLOBAL.weirdpizzashrooms;
		
	 collectfontR = global.PPfont;
	 collectpaletteR = global.PPfontpalette;
}