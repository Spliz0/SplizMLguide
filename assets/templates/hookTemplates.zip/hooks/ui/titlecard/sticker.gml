/*
If your character will use stickers instead of titlecards,
return a sprite, the images will be picked randomly
*/

if character == "PP"
{
    return MOD_GLOBAL.spr_PPstickers;
}