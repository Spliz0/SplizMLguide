/*
runs after the titlecard is drawn 
(skip titlecard text still shows over)
animated titlecard example
*/
if obj_player1.character == "PP" && global.leveltosave == "entrance"
{
    if elapsed > 20
    {
        if elapsed < 80
        draw_sprite(MOD_GLOBAL.JG1,elapsedd,SCREEN_WIDTH * 0.5,SCREEN_HEIGHT* 0.5)
        else
        draw_sprite(MOD_GLOBAL.JG2,elapsedd,SCREEN_WIDTH * 0.5,SCREEN_HEIGHT * 0.5)
    }



}