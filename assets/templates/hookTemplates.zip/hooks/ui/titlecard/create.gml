//runs when the titlecard is created
//setup variables for a fancy titlecard or something


elapsed = 0;
elapsedd = 0;