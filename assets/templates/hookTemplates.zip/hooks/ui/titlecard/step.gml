//runs every step during the titlecard code,
//do something funny like the vigilante golf 
//title with this probably

//example for animated titlecard thing
elapsedd += 0.35;
elapsed += 1;
