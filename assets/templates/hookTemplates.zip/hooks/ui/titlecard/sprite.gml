//set a sprite for the titlecard to use
//2 examples if you have all or only some cards done
//this hook applies with cyop too!

// 1: ALL READY
if character == "PP" && !instance_exists(obj_cyop_loader)
{
    titlecard_sprite = MOD_GLOBAL.spr_PPtitlecards;
}

//2: only gutter
if character == "PP" && global.leveltosave == "entrance"
{
    titlecard_sprite = MOD_GLOBAL.spr_PPguttercard;
}