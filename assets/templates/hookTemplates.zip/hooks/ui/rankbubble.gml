/*
return an array, 3 parts
[image_index,ranksprite,isprank]
the image you want to show, the sprite you want to pull that image from,
and if that sprite is a Prank so it plays the animation and runs the code
*/

if obj_player1.character == "PP" && MODIFIERS.PPmode
{
    if (global.collect >= global.srank)
    return[4,MOD_GLOBAL.PPranks,false]
}