/*
this is used to add lines of information when the
player uses the debug HUD option

return a string to have it added to the end of the line

To add multiple lines with one mod, 
just add \n at the end of your string
*/

var myvar = concat("Explosions:",global.PPexplosions)
return myvar;